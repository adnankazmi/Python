import { Reveal, SectionHeading } from "./primitives";

const CAREER_PATHS = [
  {
    role: "Data Analyst",
    body: "Cleaning, analysing and reporting on datasets using Python, Pandas and visualization.",
  },
  {
    role: "Python Developer (Data focus)",
    body: "Writing practical Python for data processing, automation and analysis workflows.",
  },
  {
    role: "Junior Data Scientist",
    body: "Building on EDA, preprocessing and machine learning foundations covered in the program.",
  },
  {
    role: "AI / ML Learner Track",
    body: "A structured base for continued study in machine learning and applied AI.",
  },
];

const VALUE = [
  "Python skills are in demand across analytics, automation and research roles.",
  "Data handling and EDA are everyday tasks in most data-facing positions.",
  "Visualization turns analysis into decisions stakeholders can act on.",
  "Project work gives you something concrete to show and discuss.",
];

export function Instructor() {
  return (
    <>
      {/* Instructor */}
      <section id="instructor" className="bg-surface py-20 sm:py-28">
        <div className="container-itec">
          <SectionHeading
            eyebrow="Instructor"
            title="Who teaches the program"
            intro="Sessions are delivered live by an ITEC instructor. Full instructor details will be published once confirmed by ITEC."
          />

          <div className="mt-14 grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
            <Reveal className="relative overflow-hidden rounded-xl bg-[image:var(--gradient-ink)] p-8 shadow-lift">
              <span className="pointer-events-none absolute inset-0 bg-grid-ink opacity-40" />
              <div className="relative">
                <div className="grid h-16 w-16 place-items-center rounded-lg border border-ink-border bg-ink-soft font-mono text-sm text-brand">
                  ITEC
                </div>
                <p className="mt-6 font-display text-2xl font-semibold text-ink-foreground">
                  Instructor Name
                  <span className="ml-2 align-middle font-mono text-[0.6rem] tracking-[0.16em] text-brand uppercase">
                    Placeholder
                  </span>
                </p>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">
                  Instructor profile, professional background and experience will be added here once
                  ITEC provides the final details.
                </p>
              </div>
            </Reveal>

            <Reveal delay={90} className="rounded-xl border border-border bg-card p-8 shadow-card">
              <p className="eyebrow">Teaching approach</p>
              <ul className="mt-5 space-y-4">
                {[
                  "Live explanation of every concept, followed by hands-on practice.",
                  "Work on real-world datasets rather than toy examples only.",
                  "Questions answered during the session, in context.",
                  "Structured progression — each module builds on the previous one.",
                ].map((item) => (
                  <li key={item} className="flex gap-3 text-sm leading-relaxed text-muted-foreground">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brand" />
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Career paths */}
      <section className="py-20 sm:py-28">
        <div className="container-itec">
          <SectionHeading
            eyebrow="Career relevance"
            title="Where these skills are applied"
            intro="The program builds practical, transferable skills. It does not guarantee employment — the paths below describe where Python, data analysis and ML foundations are commonly used."
          />

          <div className="mt-14 grid gap-4 sm:grid-cols-2">
            {CAREER_PATHS.map((path, i) => (
              <Reveal
                key={path.role}
                delay={i * 70}
                className="group rounded-lg border border-border bg-card p-7 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-card"
              >
                <h3 className="text-lg font-semibold">{path.role}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{path.body}</p>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 grid gap-4 rounded-lg border border-border bg-surface p-7 sm:grid-cols-2">
            {VALUE.map((item, i) => (
              <Reveal key={item} delay={i * 60} className="flex gap-3 text-sm text-muted-foreground">
                <span className="font-mono text-xs text-brand-strong">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {item}
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
