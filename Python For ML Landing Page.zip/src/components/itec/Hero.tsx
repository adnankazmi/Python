import { EnrollButton, GhostButton } from "./primitives";
import { PROGRAM } from "@/lib/itec";

const CODE_LINES: Array<Array<{ t: string; c?: string }>> = [
  [
    { t: "import", c: "kw" },
    { t: " pandas " },
    { t: "as", c: "kw" },
    { t: " pd" },
  ],
  [
    { t: "from", c: "kw" },
    { t: " sklearn.model_selection " },
    { t: "import", c: "kw" },
    { t: " train_test_split" },
  ],
  [{ t: "" }],
  [
    { t: "df " },
    { t: "=", c: "op" },
    { t: " pd." },
    { t: "read_csv", c: "fn" },
    { t: "(" },
    { t: '"dataset.csv"', c: "str" },
    { t: ")" },
  ],
  [
    { t: "df " },
    { t: "=", c: "op" },
    { t: " df." },
    { t: "dropna", c: "fn" },
    { t: "()" },
  ],
  [
    { t: "X, y " },
    { t: "=", c: "op" },
    { t: " df[features], df[" },
    { t: '"target"', c: "str" },
    { t: "]" },
  ],
  [{ t: "" }],
  [
    { t: "model." },
    { t: "fit", c: "fn" },
    { t: "(X_train, y_train)" },
  ],
  [
    { t: "preds " },
    { t: "=", c: "op" },
    { t: " model." },
    { t: "predict", c: "fn" },
    { t: "(X_test)" },
  ],
];

const codeColor: Record<string, string> = {
  kw: "text-brand",
  fn: "text-ink-foreground",
  str: "text-brand/80",
  op: "text-ink-muted",
};

const PIPELINE = ["Python", "Data", "Model", "Prediction"];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-surface pt-28 pb-16 sm:pt-32 lg:pb-24">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-[0.55]" />
      <div className="pointer-events-none absolute -top-32 -right-24 h-[28rem] w-[28rem] rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--brand)_22%,transparent),transparent_65%)] blur-2xl" />

      <div className="container-itec relative grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
        <div className="animate-rise">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            <span className="font-mono text-[0.65rem] tracking-[0.16em] text-muted-foreground uppercase">
              {PROGRAM.legalName}
            </span>
          </div>

          <h1 className="mt-6 text-[2.6rem] leading-[1.04] font-semibold sm:text-6xl">
            Python for
            <br />
            <span className="text-gradient-brand">Machine Learning</span>
          </h1>

          <p className="mt-5 max-w-xl text-lg text-muted-foreground">
            {PROGRAM.subtitle}. Learn Python in the context of data, analysis and machine learning —
            live, structured and practical.
          </p>

          <ul className="mt-7 flex flex-wrap items-center gap-x-3 gap-y-2 font-mono text-xs tracking-wide text-foreground/80">
            {["8 Weeks", "Live Online", "32 Learning Hours", "Saturday + Sunday", "Google Meet"].map(
              (item, i) => (
                <li key={item} className="flex items-center gap-3">
                  {i > 0 ? <span className="text-border">/</span> : null}
                  <span>{item}</span>
                </li>
              ),
            )}
          </ul>

          <div className="mt-9 flex flex-col gap-5 rounded-lg border border-border bg-background p-6 shadow-card sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="eyebrow">Launching Offer</p>
              <div className="mt-2 flex items-end gap-3">
                <span className="font-display text-4xl font-semibold tracking-tight">
                  {PROGRAM.offerFee}
                </span>
                <span className="pb-1 text-sm text-muted-foreground line-through">
                  {PROGRAM.regularFee}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Limited to {PROGRAM.seats} seats • Orientation {PROGRAM.orientation}
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:items-end">
              <EnrollButton />
            </div>
          </div>

          <div className="mt-5">
            <GhostButton href="#curriculum" className="h-11 px-5 text-sm">
              View Course Details
            </GhostButton>
          </div>
        </div>

        <div className="relative lg:pl-4">
          <div className="relative overflow-hidden rounded-xl bg-[image:var(--gradient-ink)] p-1 shadow-lift">
            <div className="absolute inset-0 bg-grid-ink opacity-50" />
            <div className="relative rounded-lg">
              <div className="flex items-center gap-2 border-b border-ink-border px-4 py-3">
                <span className="h-2 w-2 rounded-full bg-ink-border" />
                <span className="h-2 w-2 rounded-full bg-ink-border" />
                <span className="h-2 w-2 rounded-full bg-brand/70" />
                <span className="ml-2 font-mono text-[0.65rem] tracking-wide text-ink-muted">
                  ml_pipeline.ipynb
                </span>
              </div>

              <div className="relative overflow-hidden px-4 py-5 sm:px-6">
                <div className="animate-scan pointer-events-none absolute inset-x-0 top-0 h-16 bg-[linear-gradient(180deg,transparent,color-mix(in_oklab,var(--brand)_16%,transparent),transparent)]" />
                <pre className="relative font-mono text-[0.72rem] leading-6 text-ink-muted sm:text-[0.8rem]">
                  {CODE_LINES.map((line, i) => (
                    <div key={i} className="flex gap-4">
                      <span className="w-4 shrink-0 text-right text-ink-muted/40">{i + 1}</span>
                      <span className="truncate">
                        {line.map((tok, j) => (
                          <span key={j} className={tok.c ? codeColor[tok.c] : undefined}>
                            {tok.t}
                          </span>
                        ))}
                        {i === CODE_LINES.length - 1 ? (
                          <span className="animate-caret ml-0.5 inline-block h-3.5 w-1.5 translate-y-0.5 bg-brand" />
                        ) : null}
                      </span>
                    </div>
                  ))}
                </pre>
              </div>

              <div className="relative border-t border-ink-border px-4 py-5 sm:px-6">
                <div className="flex items-center justify-between gap-2">
                  {PIPELINE.map((step, i) => (
                    <div key={step} className="flex flex-1 items-center gap-2">
                      <div className="flex flex-col gap-1.5">
                        <span className="font-mono text-[0.6rem] tracking-[0.14em] text-ink-muted uppercase">
                          {step}
                        </span>
                        <span
                          className="h-1 rounded-full bg-brand"
                          style={{ width: `${28 + i * 10}px`, opacity: 0.4 + i * 0.2 }}
                        />
                      </div>
                      {i < PIPELINE.length - 1 ? (
                        <span className="hidden h-px flex-1 bg-ink-border sm:block" />
                      ) : null}
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex items-end gap-1.5">
                  {[34, 52, 41, 68, 57, 78, 62, 88, 73, 94, 81, 100].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-t-[2px] bg-brand"
                      style={{ height: `${h * 0.5}px`, opacity: 0.25 + (i / 12) * 0.7 }}
                    />
                  ))}
                </div>
                <div className="mt-3 flex justify-between font-mono text-[0.6rem] text-ink-muted">
                  <span>train → evaluate</span>
                  <span className="text-brand">model output</span>
                </div>
              </div>
            </div>
          </div>

          <div className="animate-drift absolute -bottom-6 -left-4 hidden rounded-lg border border-border bg-background px-4 py-3 shadow-card sm:block">
            <p className="font-mono text-[0.6rem] tracking-[0.14em] text-muted-foreground uppercase">
              Live hours
            </p>
            <p className="font-display text-2xl font-semibold">
              24<span className="text-brand">+8</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
