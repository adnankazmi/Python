/** Central ITEC program constants. Replace placeholders when ITEC confirms them. */

/** Google Form enrollment link. Empty until ITEC provides the final URL. */
export const ENROLL_FORM_URL = "";

export const PROGRAM = {
  brand: "ITEC",
  legalName: "IT Excellence Circle LLP",
  title: "Python for Machine Learning",
  subtitle: "Practical AI & Machine Learning Program",
  format: "Live Online Training",
  platform: "Google Meet",
  duration: "8 Weeks",
  days: "Saturday + Sunday",
  sessionLength: "2 Hours",
  liveHours: 24,
  projectHours: 8,
  totalHours: 32,
  orientation: "7 September 2026",
  firstClass: "12 September 2026",
  seats: 30,
  regularFee: "PKR 20,000",
  offerFee: "PKR 15,000",
  email: "info@itexcellencecircle.site",
} as const;

export const MODULES = [
  {
    id: "01",
    name: "Python Foundations",
    weeks: "Weeks 1–2",
    summary: "Core language fundamentals with continuous hands-on practice.",
    topics: [
      "Introduction to Python",
      "Why Python",
      "Installing Python",
      "Python IDEs",
      "Python syntax",
      "Variables",
      "Data types",
      "Operators",
      "Python built-in functions",
      "Conditional statements",
      "Looping statements",
      "Lists",
      "Tuples",
      "Sets",
      "Dictionaries",
      "Comprehensions",
      "Error handling",
      "Practical exercises",
      "Real-world problem solving using Python",
    ],
  },
  {
    id: "02",
    name: "Data Handling with Python",
    weeks: "Weeks 3–4",
    summary: "Moving from language basics to working with real data structures and files.",
    topics: [
      "File I/O",
      "Regular expressions",
      "Introduction to Python libraries",
      "Introduction to NumPy",
      "Introduction to Pandas",
      "DataFrames",
      "Series",
      "Reading and writing data",
      "Data cleaning",
      "Real-world dataset analysis using Python and Pandas",
    ],
  },
  {
    id: "03",
    name: "Data Analysis & EDA",
    weeks: "Weeks 5–6",
    summary: "Structured analysis workflows on real datasets.",
    topics: [
      "Advanced Pandas",
      "Data indexing and selection",
      "Grouping and aggregation",
      "Missing data",
      "Pivot tables",
      "Introduction to data analysis",
      "Data analysis workflow",
      "Exploratory Data Analysis (EDA)",
      "Data preprocessing",
      "Comprehensive real-world dataset analysis",
    ],
  },
  {
    id: "04",
    name: "Data Visualization",
    weeks: "Weeks 7–8",
    summary: "Communicating findings clearly, alongside project work.",
    topics: [
      "Introduction to Matplotlib",
      "Basic plots",
      "Histograms",
      "Scatter plots",
      "Customizing plots",
      "Multiple subplots",
      "Text and annotations",
      "Saving figures",
      "Real-world dataset visualization",
    ],
  },
] as const;

export const FAQS = [
  {
    q: "What is Python for Machine Learning?",
    a: "It is an 8-week live online program from ITEC that teaches Python as the working foundation for data handling, data analysis, visualization and machine learning fundamentals.",
  },
  {
    q: "Is this only a Python programming course?",
    a: "No. Python is taught as a foundation for working with data and machine learning. The program also covers NumPy, Pandas, data analysis, visualization and machine learning foundations.",
  },
  {
    q: "Is the course suitable for beginners?",
    a: "Participants should have basic programming knowledge. Advanced Python or ML knowledge is not required.",
  },
  {
    q: "Do I need previous Machine Learning experience?",
    a: "No advanced ML experience is required.",
  },
  { q: "Is the course online?", a: "Yes. Classes are conducted live online through Google Meet." },
  { q: "Which days are classes held?", a: "Saturday and Sunday." },
  { q: "How long is each class?", a: "2 hours." },
  {
    q: "How many total learning hours are included?",
    a: "32 total learning hours: 24 live training hours plus 8 project hours.",
  },
  {
    q: "Will classes be recorded?",
    a: "No. The program is designed around live participation and attendance.",
  },
  {
    q: "What tools will I learn?",
    a: "Python, Jupyter Notebook, Anaconda, NumPy, Pandas and related data-analysis tools.",
  },
  {
    q: "Will I work on real-world data?",
    a: "Yes. The curriculum includes hands-on exercises and real-world dataset analysis.",
  },
  {
    q: "Will there be projects?",
    a: "Yes. The program includes dedicated project work. Specific project topics will be finalized by the instructor.",
  },
  {
    q: "Who can join?",
    a: "Students, fresh graduates, working professionals, career switchers and developers with basic programming knowledge.",
  },
  { q: "What is the course fee?", a: "Regular fee: PKR 20,000. Launching offer: PKR 15,000." },
  { q: "How many seats are available?", a: "30 seats." },
  { q: "When is orientation?", a: "7 September 2026." },
  { q: "When do regular classes begin?", a: "12 September 2026." },
  {
    q: "Will I receive a certificate?",
    a: "Participants who meet ITEC's completion requirements will receive the relevant ITEC certificate.",
  },
] as const;
