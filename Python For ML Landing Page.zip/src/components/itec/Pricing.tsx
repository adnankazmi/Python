import { Reveal, SectionHeading, EnrollButton } from "./primitives";
import { PROGRAM } from "@/lib/itec";

const INCLUDED = [
  `${PROGRAM.liveHours} live online training hours`,
  `${PROGRAM.projectHours} dedicated project hours`,
  "Hands-on exercises in every session",
  "Real-world dataset analysis",
  "Live Q&A during sessions",
  "ITEC certificate on completion requirements",
];

export function Pricing() {
  return (
    <section id="pricing" className="py-20 sm:py-28">
      <div className="container-itec">
        <SectionHeading
          eyebrow="Pricing"
          title="One program, one fee"
          intro="A launching offer is available for this cohort. No hidden charges."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal className="relative overflow-hidden rounded-xl border border-brand/30 bg-card p-8 shadow-lift">
            <span className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-[image:var(--gradient-brand)]" />
            <p className="eyebrow">Launching offer</p>
            <div className="mt-4 flex items-end gap-3">
              <span className="font-display text-5xl font-semibold tracking-tight">
                {PROGRAM.offerFee}
              </span>
              <span className="pb-2 text-base text-muted-foreground line-through">
                {PROGRAM.regularFee}
              </span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Limited to {PROGRAM.seats} seats for this cohort.
            </p>

            <div className="mt-7">
              <EnrollButton className="w-full" />
            </div>

            <p className="mt-4 text-xs text-muted-foreground">
              Payment instructions placeholder — will be added once provided by ITEC.
            </p>
          </Reveal>

          <Reveal delay={100} className="rounded-xl border border-border bg-surface p-8">
            <p className="eyebrow">What's included</p>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {INCLUDED.map((item) => (
                <li key={item} className="flex gap-3 text-sm text-muted-foreground">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand" />
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-8 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-3">
              {[
                { k: "Orientation", v: PROGRAM.orientation },
                { k: "Classes begin", v: PROGRAM.firstClass },
                { k: "Seats", v: `${PROGRAM.seats}` },
              ].map((s) => (
                <div key={s.k} className="bg-background px-5 py-4">
                  <p className="font-mono text-[0.6rem] tracking-[0.14em] text-muted-foreground uppercase">
                    {s.k}
                  </p>
                  <p className="mt-1 text-sm font-medium">{s.v}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
