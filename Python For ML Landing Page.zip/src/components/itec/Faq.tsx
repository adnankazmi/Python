import { Reveal, SectionHeading } from "./primitives";
import { FAQS } from "@/lib/itec";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export function Faq() {
  return (
    <section id="faq" className="bg-surface py-20 sm:py-28">
      <div className="container-itec">
        <SectionHeading
          eyebrow="FAQ"
          title="Frequently asked questions"
          intro="Everything ITEC has confirmed about this cohort."
        />

        <Reveal className="mt-12">
          <Accordion type="single" collapsible className="grid gap-3 lg:grid-cols-2 lg:gap-x-6">
            {FAQS.map((faq, i) => (
              <AccordionItem
                key={faq.q}
                value={`faq-${i}`}
                className="rounded-lg border border-border bg-background px-5 last:border-b"
              >
                <AccordionTrigger className="text-left text-sm font-medium hover:no-underline">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}
