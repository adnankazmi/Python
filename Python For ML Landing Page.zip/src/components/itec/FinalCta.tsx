import { Reveal, EnrollButton } from "./primitives";
import { Logo } from "./Header";
import { PROGRAM } from "@/lib/itec";

export function FinalCta() {
  return (
    <section className="relative overflow-hidden bg-[image:var(--gradient-ink)] py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 bg-grid-ink opacity-40" />
      <div className="pointer-events-none absolute -bottom-32 left-1/2 h-[26rem] w-[26rem] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--brand)_28%,transparent),transparent_65%)] blur-2xl" />

      <Reveal className="container-itec relative text-center">
        <p className="eyebrow text-brand">Enrollment open</p>
        <h2 className="mx-auto mt-4 max-w-2xl text-3xl leading-[1.1] font-semibold text-ink-foreground sm:text-5xl">
          Start with Python. Build towards machine learning.
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-base text-ink-muted">
          {PROGRAM.duration} live online, {PROGRAM.totalHours} learning hours, {PROGRAM.seats} seats.
          Orientation on {PROGRAM.orientation}.
        </p>
        <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <EnrollButton />
          <span className="font-mono text-xs tracking-wide text-ink-muted">
            {PROGRAM.offerFee} launching offer • was {PROGRAM.regularFee}
          </span>
        </div>
      </Reveal>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-background py-14">
      <div className="container-itec grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            {PROGRAM.legalName} delivers structured, practical technology training. This program
            builds real skills — it does not promise employment.
          </p>
        </div>

        <div>
          <p className="eyebrow">Program</p>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {[
              { href: "#program", label: "Overview" },
              { href: "#curriculum", label: "Curriculum" },
              { href: "#details", label: "Schedule" },
              { href: "#pricing", label: "Pricing" },
              { href: "#faq", label: "FAQ" },
            ].map((l) => (
              <li key={l.href}>
                <a href={l.href} className="transition-colors hover:text-brand-strong">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="eyebrow">Contact</p>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <a
                href={`mailto:${PROGRAM.email}`}
                className="transition-colors hover:text-brand-strong"
              >
                {PROGRAM.email}
              </a>
            </li>
            <li>Live online • {PROGRAM.platform}</li>
            <li className="text-xs">Social links placeholder</li>
          </ul>
        </div>
      </div>

      <div className="container-itec mt-12 flex flex-col gap-2 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <span>
          © {new Date().getFullYear()} {PROGRAM.legalName}. All rights reserved.
        </span>
        <span>{PROGRAM.title} — {PROGRAM.format}</span>
      </div>
    </footer>
  );
}

export function StickyCta() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 px-4 py-3 backdrop-blur-md sm:hidden">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="font-display text-base font-semibold leading-tight">{PROGRAM.offerFee}</p>
          <p className="text-[0.65rem] text-muted-foreground">
            was {PROGRAM.regularFee} • {PROGRAM.seats} seats
          </p>
        </div>
        <EnrollButton size="md" />
      </div>
    </div>
  );
}
