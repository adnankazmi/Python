import { Reveal, SectionHeading, Counter } from "./primitives";
import { PROGRAM } from "@/lib/itec";

const ROADMAP = [
  { label: "Python", note: "Language foundations" },
  { label: "Data Handling", note: "Files, NumPy, Pandas" },
  { label: "Data Analysis", note: "Workflows & EDA" },
  { label: "Visualization", note: "Matplotlib" },
  { label: "Machine Learning", note: "Foundations" },
  { label: "Practical Projects", note: "Applied work" },
];

const WHY = [
  {
    k: "01",
    title: "The working language of data",
    body: "Python is widely used across data processing, analysis and machine learning workflows, which keeps one language relevant from raw files to model output.",
  },
  {
    k: "02",
    title: "A mature library ecosystem",
    body: "NumPy, Pandas and Matplotlib cover numerical work, tabular data and visualization, so learners spend time on problems rather than infrastructure.",
  },
  {
    k: "03",
    title: "Readable, practical syntax",
    body: "Clear syntax makes analysis code easier to write, review and maintain — an advantage when working with datasets in teams.",
  },
  {
    k: "04",
    title: "Industry relevance",
    body: "Python is commonly used in analytics, automation, research and applied AI work, making it a practical foundation for continued learning.",
  },
];

export function Program() {
  return (
    <>
      {/* Stats band */}
      <section className="border-y border-border bg-background">
        <div className="container-itec grid grid-cols-2 divide-border sm:grid-cols-4 sm:divide-x">
          {[
            { v: 8, s: "", label: "Weeks" },
            { v: 24, s: "", label: "Live training hours" },
            { v: 8, s: "", label: "Project hours" },
            { v: 32, s: "", label: "Total learning hours" },
          ].map((stat, i) => (
            <Reveal
              key={stat.label}
              delay={i * 70}
              className="px-2 py-8 text-center sm:px-6 sm:text-left"
            >
              <p className="font-display text-4xl font-semibold tracking-tight">
                <Counter to={stat.v} suffix={stat.s} />
              </p>
              <p className="mt-1 text-xs tracking-wide text-muted-foreground uppercase">
                {stat.label}
              </p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Positioning + roadmap */}
      <section id="program" className="py-20 sm:py-28">
        <div className="container-itec">
          <SectionHeading
            eyebrow="Positioning"
            title={
              <>
                Learn Python in the context of{" "}
                <span className="text-gradient-brand">data and machine learning</span>
              </>
            }
            intro="This is not a standalone programming course. Python is introduced as the foundation for working with data, running analysis and building the groundwork for machine learning solutions — one continuous, practical pathway."
          />

          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {ROADMAP.map((step, i) => (
              <Reveal
                key={step.label}
                delay={i * 60}
                className="group relative overflow-hidden rounded-lg border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-card"
              >
                <span className="font-mono text-[0.65rem] tracking-[0.16em] text-brand-strong">
                  STEP {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-3 text-lg font-semibold">{step.label}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{step.note}</p>
                <span className="absolute inset-x-6 bottom-0 h-px origin-left scale-x-0 bg-[image:var(--gradient-brand)] transition-transform duration-500 group-hover:scale-x-100" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Why Python */}
      <section className="relative overflow-hidden bg-[image:var(--gradient-ink)] py-20 sm:py-28">
        <div className="pointer-events-none absolute inset-0 bg-grid-ink opacity-40" />
        <div className="container-itec relative">
          <SectionHeading
            eyebrow="Why Python"
            invert
            title="Why Python for machine learning?"
            intro="Python sits at the centre of most modern data and machine learning workflows. Here is what that means in practice for a learner."
          />

          <div className="mt-14 grid gap-px overflow-hidden rounded-lg border border-ink-border bg-ink-border sm:grid-cols-2">
            {WHY.map((item, i) => (
              <Reveal
                key={item.k}
                delay={i * 70}
                className="bg-[color-mix(in_oklab,var(--ink)_92%,black)] p-7 transition-colors duration-300 hover:bg-ink-soft"
              >
                <span className="font-mono text-xs text-brand">{item.k}</span>
                <h3 className="mt-3 text-lg font-semibold text-ink-foreground">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">{item.body}</p>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-8 text-xs text-ink-muted">
            The program builds practical skills. It does not promise employment or claim to make
            anyone an AI engineer in {PROGRAM.duration.toLowerCase()}.
          </Reveal>
        </div>
      </section>
    </>
  );
}
