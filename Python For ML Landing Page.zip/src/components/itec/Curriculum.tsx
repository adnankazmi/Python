import { Reveal, SectionHeading } from "./primitives";
import { MODULES } from "@/lib/itec";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const TOOLS = [
  { name: "Python", note: "Core language" },
  { name: "Jupyter Notebook", note: "Interactive analysis" },
  { name: "Anaconda", note: "Environment & packages" },
];

const SKILLS = [
  "Python Programming",
  "NumPy",
  "Pandas",
  "Data Cleaning",
  "Data Analysis",
  "Exploratory Data Analysis",
  "Data Visualization",
  "Machine Learning foundations",
  "Practical problem solving",
];

const PRACTICE = [
  { step: "Understand", note: "Concepts explained live with worked examples." },
  { step: "Practice", note: "Hands-on Python exercises in every session." },
  { step: "Analyze", note: "Data cleaning and EDA on real-world datasets." },
  { step: "Visualize", note: "Communicate findings with clear plots." },
  { step: "Build", note: "Project work applying the full workflow." },
];

export function Curriculum() {
  return (
    <>
      <section id="curriculum" className="py-20 sm:py-28">
        <div className="container-itec">
          <SectionHeading
            eyebrow="Curriculum"
            title="What you will learn"
            intro="Four confirmed modules delivered across eight weeks, each one building directly on the previous."
          />

          <div className="mt-14 grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="space-y-3">
              {MODULES.map((m, i) => (
                <Reveal
                  key={m.id}
                  delay={i * 60}
                  className="flex gap-5 rounded-lg border border-border bg-card p-6 shadow-card"
                >
                  <span className="font-display text-2xl font-semibold text-brand">{m.id}</span>
                  <div>
                    <p className="font-mono text-[0.65rem] tracking-[0.16em] text-muted-foreground uppercase">
                      {m.weeks}
                    </p>
                    <h3 className="mt-1.5 text-lg font-semibold">{m.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{m.summary}</p>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={120}>
              <Accordion type="single" collapsible defaultValue="01" className="w-full">
                {MODULES.map((m) => (
                  <AccordionItem key={m.id} value={m.id} className="border-border">
                    <AccordionTrigger className="text-left hover:no-underline">
                      <span className="flex items-baseline gap-3">
                        <span className="font-mono text-xs text-brand-strong">M{m.id}</span>
                        <span className="font-display text-base font-medium">{m.name}</span>
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="grid gap-x-6 gap-y-1.5 pb-2 sm:grid-cols-2">
                        {m.topics.map((t) => (
                          <li
                            key={t}
                            className="flex items-start gap-2 text-sm text-muted-foreground"
                          >
                            <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-brand" />
                            {t}
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Tools & skills */}
      <section className="border-y border-border bg-surface py-20 sm:py-24">
        <div className="container-itec grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <SectionHeading
            eyebrow="Tools & Skills"
            title="The stack you will work in"
            intro="A focused toolset, used consistently throughout the program."
          />
          <div>
            <div className="grid gap-4 sm:grid-cols-3">
              {TOOLS.map((tool, i) => (
                <Reveal
                  key={tool.name}
                  delay={i * 70}
                  className="rounded-lg border border-border bg-background p-6 transition-transform duration-300 hover:-translate-y-1"
                >
                  <span className="font-mono text-[0.65rem] text-brand-strong">TOOL</span>
                  <h3 className="mt-2 font-display text-base font-semibold">{tool.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{tool.note}</p>
                </Reveal>
              ))}
            </div>
            <Reveal delay={140} className="mt-6 flex flex-wrap gap-2">
              {SKILLS.map((s) => (
                <span
                  key={s}
                  className="rounded-md border border-border bg-background px-3 py-1.5 font-mono text-xs text-foreground/80 transition-colors hover:border-brand hover:text-brand-strong"
                >
                  {s}
                </span>
              ))}
            </Reveal>
          </div>
        </div>
      </section>

      {/* Practical learning */}
      <section className="py-20 sm:py-28">
        <div className="container-itec">
          <SectionHeading
            eyebrow="Practical Learning"
            title="Learn by working with data"
            intro="Sessions are built around doing the work: writing Python, cleaning datasets, running analysis and producing visual output — not only watching lectures."
          />

          <div className="mt-14 grid gap-3 md:grid-cols-5">
            {PRACTICE.map((p, i) => (
              <Reveal
                key={p.step}
                delay={i * 70}
                className="relative rounded-lg border border-border bg-card p-6"
              >
                <span className="font-mono text-[0.65rem] text-brand-strong">
                  0{i + 1}
                </span>
                <h3 className="mt-2 font-display text-base font-semibold">{p.step}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{p.note}</p>
                {i < PRACTICE.length - 1 ? (
                  <span className="absolute top-1/2 -right-3 hidden h-px w-6 bg-border md:block" />
                ) : null}
              </Reveal>
            ))}
          </div>

          <Reveal
            delay={120}
            className="mt-8 rounded-lg border border-border bg-surface p-6 text-sm text-muted-foreground"
          >
            Work includes hands-on Python exercises, dataset analysis, data cleaning, EDA,
            visualization and practical machine learning work through project-based learning.
            Specific project topics are finalized by the instructor based on the cohort.
          </Reveal>
        </div>
      </section>
    </>
  );
}
