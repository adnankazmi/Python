import { Reveal, SectionHeading, EnrollButton } from "./primitives";
import { PROGRAM } from "@/lib/itec";

const DETAILS = [
  { k: "Format", v: PROGRAM.format },
  { k: "Platform", v: PROGRAM.platform },
  { k: "Duration", v: PROGRAM.duration },
  { k: "Class days", v: PROGRAM.days },
  { k: "Session length", v: PROGRAM.sessionLength },
  { k: "Live training hours", v: `${PROGRAM.liveHours} hours` },
  { k: "Project hours", v: `${PROGRAM.projectHours} hours` },
  { k: "Total learning hours", v: `${PROGRAM.totalHours} hours` },
  { k: "Orientation", v: PROGRAM.orientation },
  { k: "Regular classes begin", v: PROGRAM.firstClass },
  { k: "Seats", v: `${PROGRAM.seats} seats` },
  { k: "Recordings", v: "Not provided — live participation" },
];

const AUDIENCE = [
  "Students",
  "Fresh graduates",
  "Working professionals",
  "Career switchers",
  "Developers with basic programming knowledge",
];

export function Details() {
  return (
    <section id="details" className="bg-surface py-20 sm:py-28">
      <div className="container-itec">
        <SectionHeading
          eyebrow="Program details"
          title="Schedule, format and requirements"
          intro="Everything confirmed by ITEC about how the program runs."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
          <Reveal className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
            <dl className="grid sm:grid-cols-2">
              {DETAILS.map((row) => (
                <div key={row.k} className="border-b border-border px-6 py-5 last:border-b-0">
                  <dt className="font-mono text-[0.65rem] tracking-[0.14em] text-muted-foreground uppercase">
                    {row.k}
                  </dt>
                  <dd className="mt-1.5 text-sm font-medium text-foreground">{row.v}</dd>
                </div>
              ))}
            </dl>
          </Reveal>

          <div className="flex flex-col gap-6">
            <Reveal delay={80} className="rounded-xl border border-border bg-background p-7">
              <p className="eyebrow">Who should join</p>
              <ul className="mt-4 flex flex-wrap gap-2">
                {AUDIENCE.map((a) => (
                  <li
                    key={a}
                    className="rounded-full border border-border bg-surface px-3 py-1.5 text-xs text-muted-foreground"
                  >
                    {a}
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                Basic programming knowledge is required. Advanced Python or machine learning
                experience is not.
              </p>
            </Reveal>

            <Reveal
              delay={140}
              className="relative overflow-hidden rounded-xl bg-[image:var(--gradient-ink)] p-7 shadow-lift"
            >
              <span className="pointer-events-none absolute inset-0 bg-grid-ink opacity-40" />
              <div className="relative">
                <p className="eyebrow text-brand">Certificate</p>
                <h3 className="mt-3 text-xl font-semibold text-ink-foreground">
                  ITEC Certificate of Completion
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">
                  Participants who meet ITEC's completion requirements will receive the relevant
                  ITEC certificate.
                </p>
                <div className="mt-6 rounded-lg border border-dashed border-ink-border p-5">
                  <p className="font-mono text-[0.6rem] tracking-[0.16em] text-ink-muted uppercase">
                    Certificate preview
                  </p>
                  <p className="mt-2 text-xs text-ink-muted">
                    Placeholder — certificate design will be added once provided by ITEC.
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* How to enroll */}
        <div id="enroll" className="mt-20 scroll-mt-24">
          <SectionHeading
            eyebrow="Enrollment"
            title="How to enroll"
            intro="Three steps. Seats are limited to 30 for this cohort."
          />

          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              {
                n: "01",
                t: "Submit the enrollment form",
                b: "Complete the ITEC Google Form with your details.",
              },
              {
                n: "02",
                t: "Complete the fee payment",
                b: "Payment details placeholder — bank / payment instructions will be added once provided by ITEC.",
              },
              {
                n: "03",
                t: "Receive confirmation",
                b: "ITEC confirms your seat and shares the Google Meet joining details before orientation.",
              },
            ].map((step, i) => (
              <Reveal
                key={step.n}
                delay={i * 80}
                className="rounded-lg border border-border bg-card p-7 shadow-card"
              >
                <span className="font-mono text-[0.65rem] tracking-[0.16em] text-brand-strong">
                  STEP {step.n}
                </span>
                <h3 className="mt-3 text-lg font-semibold">{step.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.b}</p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={200} className="mt-8 flex flex-wrap items-center gap-4">
            <EnrollButton />
            <span className="text-sm text-muted-foreground">
              Questions? Email{" "}
              <a className="text-brand-strong underline-offset-4 hover:underline" href={`mailto:${PROGRAM.email}`}>
                {PROGRAM.email}
              </a>
            </span>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
