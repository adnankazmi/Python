import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { EnrollButton } from "./primitives";
import { PROGRAM } from "@/lib/itec";

const NAV = [
  { href: "#program", label: "Program" },
  { href: "#curriculum", label: "Curriculum" },
  { href: "#instructor", label: "Instructor" },
  { href: "#details", label: "Details" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled ? "border-b border-border bg-background/85 backdrop-blur-md" : "border-b border-transparent",
      )}
    >
      <div className="container-itec flex h-16 items-center justify-between gap-6">
        <a href="#top" className="flex items-center gap-3">
          <Logo />
          <span className="hidden text-[0.7rem] leading-tight tracking-[0.16em] text-muted-foreground uppercase sm:block">
            IT Excellence
            <br />
            Circle LLP
          </span>
        </a>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Section navigation">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm text-muted-foreground transition-colors hover:text-brand-strong"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <span className="hidden text-xs text-muted-foreground xl:block">
            {PROGRAM.duration} • Live Online
          </span>
          <EnrollButton size="md" className="hidden sm:inline-flex" />
        </div>
      </div>
    </header>
  );
}

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-md bg-[image:var(--gradient-ink)]">
        <span className="absolute inset-0 bg-grid-ink opacity-60" />
        <span className="relative font-mono text-[0.68rem] font-bold tracking-tight text-ink-foreground">
          IT<span className="text-brand">C</span>
        </span>
      </span>
      <span className="font-display text-lg font-semibold tracking-tight">ITEC</span>
    </span>
  );
}
