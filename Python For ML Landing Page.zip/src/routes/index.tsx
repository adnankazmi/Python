import { createFileRoute } from "@tanstack/react-router";

import { Header } from "@/components/itec/Header";
import { Hero } from "@/components/itec/Hero";
import { Program } from "@/components/itec/Program";
import { Curriculum } from "@/components/itec/Curriculum";
import { Instructor } from "@/components/itec/Instructor";
import { Details } from "@/components/itec/Details";
import { Pricing } from "@/components/itec/Pricing";
import { Faq } from "@/components/itec/Faq";
import { FinalCta, Footer, StickyCta } from "@/components/itec/FinalCta";
import { PROGRAM, FAQS } from "@/lib/itec";

const TITLE = "Python for Machine Learning — Live Online Course | ITEC";
const DESCRIPTION =
  "8-week live online Python for Machine Learning program by IT Excellence Circle LLP. 32 learning hours, real-world datasets, projects and certificate. PKR 15,000 launching offer.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Course",
          name: PROGRAM.title,
          description: DESCRIPTION,
          provider: {
            "@type": "Organization",
            name: PROGRAM.legalName,
            email: PROGRAM.email,
          },
          hasCourseInstance: {
            "@type": "CourseInstance",
            courseMode: "Online",
            courseWorkload: "PT32H",
            startDate: "2026-09-12",
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background pb-20 sm:pb-0">
      <Header />
      <main>
        <Hero />
        <Program />
        <Curriculum />
        <Instructor />
        <Details />
        <Pricing />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
      <StickyCta />
    </div>
  );
}
