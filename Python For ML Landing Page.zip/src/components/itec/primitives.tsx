import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ENROLL_FORM_URL } from "@/lib/itec";

/** Scroll-triggered reveal wrapper. */
export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "li" | "article" | "header";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => { const entry = entries[0]; if (!entry) return;
        if (entry.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.12 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const Component = Tag as React.ElementType;
  return (
    <Component
      ref={ref as never}
      style={{ transitionDelay: `${delay}ms` }}
      className={cn("reveal", shown && "reveal-in", className)}
    >
      {children}
    </Component>
  );
}

/** Counts up to a target when scrolled into view. */
export function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => { const entry = entries[0]; if (!entry) return;
        if (!entry.isIntersecting) return;
        io.disconnect();
        const start = performance.now();
        const duration = 1100;
        const tick = (now: number) => {
          const p = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - p, 3);
          setValue(Math.round(to * eased));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [to]);

  return (
    <span ref={ref}>
      {value}
      {suffix}
    </span>
  );
}

const enrollBase =
  "group inline-flex items-center justify-center gap-2 rounded-md font-medium tracking-tight transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2";

export function EnrollButton({
  size = "lg",
  className,
  label = "Enroll Now",
}: {
  size?: "lg" | "md";
  className?: string;
  label?: string;
}) {
  const sizing = size === "lg" ? "h-13 px-7 text-base" : "h-11 px-5 text-sm";
  const shared = cn(
    enrollBase,
    sizing,
    "bg-[image:var(--gradient-brand)] text-brand-foreground shadow-[var(--shadow-brand)] hover:-translate-y-0.5 hover:brightness-[1.06] active:translate-y-0",
    className,
  );

  if (!ENROLL_FORM_URL) {
    return (
      <a href="#enroll" className={shared}>
        {label}
        <Arrow />
      </a>
    );
  }
  return (
    <a href={ENROLL_FORM_URL} target="_blank" rel="noopener noreferrer" className={shared}>
      {label}
      <Arrow />
    </a>
  );
}

export function GhostButton({
  href,
  children,
  className,
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <a
      href={href}
      className={cn(
        enrollBase,
        "h-13 border border-border bg-background px-7 text-base text-foreground hover:border-brand hover:text-brand-strong",
        className,
      )}
    >
      {children}
    </a>
  );
}

function Arrow() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      aria-hidden="true"
      className="transition-transform duration-200 group-hover:translate-x-0.5"
    >
      <path
        d="M3 8h9M8.5 4.5 12 8l-3.5 3.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  intro,
  align = "left",
  invert = false,
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: string;
  align?: "left" | "center";
  invert?: boolean;
}) {
  return (
    <Reveal
      className={cn(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
        invert && "[&_.eyebrow]:text-brand",
      )}
    >
      <p className={cn("eyebrow", invert && "text-brand")}>{eyebrow}</p>
      <h2
        className={cn(
          "mt-3 text-3xl leading-[1.12] font-semibold sm:text-4xl",
          invert ? "text-ink-foreground" : "text-foreground",
        )}
      >
        {title}
      </h2>
      {intro ? (
        <p
          className={cn(
            "mt-4 text-base leading-relaxed",
            invert ? "text-ink-muted" : "text-muted-foreground",
          )}
        >
          {intro}
        </p>
      ) : null}
    </Reveal>
  );
}
